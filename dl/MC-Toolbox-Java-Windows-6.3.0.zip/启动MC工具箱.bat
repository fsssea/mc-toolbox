@echo off
chcp 65001 >nul
where javaw >nul 2>nul
if errorlevel 1 (
  echo 需要 Java 17 或更高版本，请先安装 JDK/JRE：https://adoptium.net/
  pause
  exit /b 1
)
start "" javaw -jar "%~dp0MC工具箱.jar"
