#!/usr/bin/env bash
cd "$(dirname "$0")"
if ! ./mctool-gui --check >/dev/null 2>&1; then :; fi
exec ./mctool-gui
