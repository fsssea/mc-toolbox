#!/usr/bin/env bash
cd "$(dirname "$0")"
if ! command -v java >/dev/null 2>&1; then
  echo "需要 Java 17+：sudo apt install openjdk-17-jre" >&2
  exit 1
fi
exec java -jar "MC工具箱.jar"
